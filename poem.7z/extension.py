from flask_sqlalchemy import SQLAlchemy


# 创建拓展插件的实例
db = SQLAlchemy()